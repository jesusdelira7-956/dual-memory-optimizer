#!/usr/bin/env bash
# ==============================================================================
# Token Optimizer Installer (Portable Bundle)
# Injects the Fullerenes Context Mapping strategy into any existing project.
# ==============================================================================

set -e

CYAN='\033[0;36m'
GREEN='\033[0;32m'
NC='\033[0m'

TARGET_DIR="${1:-.}"

echo -e "${CYAN}[SYS] Integrating Token Optimizer into: ${TARGET_DIR}${NC}"

# Create architecture directories if missing
mkdir -p "${TARGET_DIR}/directives"
mkdir -p "${TARGET_DIR}/execution"

# 1. Inject Layer 3 Execution Script
cat << 'EOF' > "${TARGET_DIR}/execution/optimize_context.sh"
#!/usr/bin/env bash
set -e
if ! command -v npx &> /dev/null; then
    echo "[ERR] npx command not found."
    exit 1
fi
npx --yes fullerenes init
echo "[OK] Persistent codebase memory mapped."
EOF

chmod +x "${TARGET_DIR}/execution/optimize_context.sh"

# 2. Inject Layer 1 Directive
cat << 'EOF' > "${TARGET_DIR}/directives/context_optimization_fullerenes.md"
# Directive: Codebase Context Mapping

## Goal
Eliminate redundant token burn caused by iterative codebase navigation.

## Tool Execution (Layer 3)
`execution/optimize_context.sh`

## Execution Protocol
1. Run `execution/optimize_context.sh` once at the project root.
2. Ingest the map immediately upon session start to understand tree, definitions, and call graphs.

## Edge Cases
- Do not manually explore (`find`, `ls`, `grep`) for initial context.
- If the map becomes stale, re-run `execution/optimize_context.sh`.
EOF

# 3. Initial Run
echo -e "${CYAN}[SYS] Bootstrapping initial context map...${NC}"
cd "${TARGET_DIR}" && ./execution/optimize_context.sh

echo -e "${GREEN}[OK] Token Optimizer successfully integrated.${NC}"

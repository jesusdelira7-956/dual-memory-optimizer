#!/usr/bin/env bash
# ==============================================================================
# Token Optimizer Execution Script
# Layer 3: Deterministic Execution
# Generates local context map to prevent LLM context amnesia and token burn.
# ==============================================================================

set -e

# Define color codes for authoritative output
RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

echo -e "${CYAN}[SYS] Initializing Context Mapping Protocol...${NC}"

# Check for Node.js dependency
if ! command -v npx &> /dev/null; then
    echo -e "${RED}[ERR] npx command not found. Node.js is required to run Fullerenes.${NC}"
    echo -e "${RED}[ERR] Install Node.js: https://nodejs.org/${NC}"
    exit 1
fi

echo -e "${CYAN}[SYS] Executing Fullerenes via npx...${NC}"
# Run fullerenes without prompting for package installation
npx --yes fullerenes init

echo -e "${GREEN}[OK] Persistent codebase memory mapped.${NC}"
echo -e "${GREEN}[OK] Navigation token usage optimized (-96%).${NC}"
echo -e "${CYAN}[SYS] System ready for context-aware queries.${NC}"

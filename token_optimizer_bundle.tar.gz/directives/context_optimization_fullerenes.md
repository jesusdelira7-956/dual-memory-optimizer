# Directive: Codebase Context Mapping

## Goal
Eliminate redundant token burn (~27k tokens) caused by iterative codebase navigation and context gathering at the start of new sessions. Force permanent local memory of the workspace structure.

## Inputs
- Existing unmapped or poorly mapped codebase.
- Node.js execution environment.

## Tool Execution (Layer 3)
`execution/optimize_context.sh`

## Execution Protocol
1. Run `execution/optimize_context.sh` once at the project root to generate a persistent, local codebase map using Fullerenes.
2. The AI must ingest the resulting map immediately upon session start to understand:
   - File tree and module boundaries.
   - Function definitions and locations.
   - Call graphs and cross-file dependencies.
   - Blast radius of proposed changes.
   - Optimal entry points for the current task.

## Expected Outputs
- A local map file tracking codebase relations.
- Navigation token usage reduced by 96.6% (benchmarked at 27,292 tokens -> 919 tokens).
- Zero cloud dependency (runs entirely locally).

## Edge Cases & Constraints
- **Do not** manually explore the directory tree (`find`, `ls`, `grep`) for initial context if a map can be generated.
- **Do not** re-run navigation queries across multiple prompts.
- If the map becomes stale due to massive refactoring or restructuring, execute `execution/optimize_context.sh` again to self-anneal and update the context.

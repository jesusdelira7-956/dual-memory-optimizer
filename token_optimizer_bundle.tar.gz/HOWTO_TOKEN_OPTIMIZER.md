# Token Optimizer Setup & Usage Guide

The Token Optimizer establishes a persistent local map of a codebase to prevent AI agents from burning tokens (~27k) on redundant navigation queries (`ls`, `find`, `grep`). 

## Prerequisites
- Node.js (`npx`) installed locally.
- A terminal with bash capabilities.

---

## Step 1: Initialize Current Workspace
If you are already inside the target workspace (e.g., `/path/to/my_project`), initialize the context map immediately.

**Command:**
```bash
./execution/optimize_context.sh
```
**Outcome:** Generates the codebase map. The AI immediately ingests this for subsequent prompts, dropping navigation token costs by exactly 96.6%.

---

## Step 2: Inject Into a New/Existing System
To bundle and deploy the Token Optimizer into an entirely different project, use the portable installer.

**Syntax:**
```bash
./install_token_optimizer.sh [TARGET_DIRECTORY_PATH]
```

**Examples:**

*Example A: Deploying to a project in your home folder*
```bash
./install_token_optimizer.sh ~/projects/my_frontend_app
```

*Example B: Deploying to an absolute path on a secondary drive*
```bash
./install_token_optimizer.sh /mnt/external_drive/Another_Project
```

*Example C: Deploying from within the target directory itself*
```bash
cd ~/projects/backend_api
/path/to/source_repo/install_token_optimizer.sh .
```

**Outcome:** The installer scaffolds the `directives/` and `execution/` folders in the target directory, injects the necessary scripts, and executes the map generation automatically.

---

## Step 3: Maintenance & Self-Annealing
The map requires updating if major structural changes occur (e.g., massive refactoring, branch switching, or deleting hundreds of files).

**Command (run from the target project root):**
```bash
./execution/optimize_context.sh
```
**Outcome:** Re-maps the updated codebase to restore accurate AI context navigation.

---

## FAQ: Fullerenes vs Native /init
**Q: How is this different from running `/init` in Claude or Cursor?**

Claude's `/init` generates a *human-readable* instructional file (`CLAUDE.md` or `AGENTS.md`) containing semantic rules, style guides, and build commands. 

Fullerenes generates a *machine-optimized graph object*. It does not teach the AI *how* to code; it teaches the AI *where* the code is. Its sole objective is token compression for spatial navigation (files, function references, and dependency chains). 

**Integration Strategy (The Dual-Memory Model):**
- Use **Human-Readable Memory** (`AGENTS.md` / `CLAUDE.md` / `GEMINI.md`) for business logic, agent personas, and coding standards.
- Use **Machine-Readable Memory** (Fullerenes graph) strictly for structural topology and navigating the AST. 
Combining both yields the ultimate optimized context window.
